// publics/js/DevFlix.js

const API_BASE_URL = 'http://localhost:3000';

document.addEventListener('DOMContentLoaded', () => {
    atualizarContadorCarrinho();

    // Identifica em qual página o usuário está
    if (document.getElementById('container-filmes-api')) {
        carregarFilmesAPI();
    }

    configurarBusca();
    configurarFormularioCadastro();
});

// -------------------------------------------------------------
// 1. CARREGAR FILMES DO BANCO DE DADOS (GET /filmes)
// -------------------------------------------------------------
async function carregarFilmesAPI() {
    const container = document.getElementById('container-filmes-api');
    if (!container) return;

    try {
        const resposta = await fetch(`${API_BASE_URL}/filmes`);
        if (!resposta.ok) throw new Error('Erro ao buscar filmes');

        const filmes = await resposta.json();

        if (filmes.length === 0) return;

        // Limpa conteúdo estático se houver dados no banco
        container.innerHTML = '';

        filmes.forEach(filme => {
            const col = document.createElement('div');
            col.className = 'col card-filme-item';
            col.innerHTML = `
                <div class="card h-100 shadow-sm">
                    <div class="row g-0 h-100">
                        <div class="col-md-4">
                            <img src="${filme.poster_url || 'https://via.placeholder.com/150x225?text=Sem+Capa'}" 
                                 class="img-fluid rounded-start h-100 object-fit-cover" 
                                 alt="${filme.titulo}">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body d-flex flex-column h-100">
                                <h5 class="card-title fw-bold">${filme.titulo}</h5>
                                <p class="card-text mb-1"><small class="text-secondary">Gênero: ${filme.genero}</small></p>
                                <p class="card-text mb-1"><small class="text-secondary">Duração: ${filme.duracao} min</small></p>
                                <p class="card-text"><small class="badge bg-danger">${filme.classificacao || 'Livre'}</small></p>
                                <button class="btn btn-devflix btn-sm mt-auto" onclick="comprarIngresso(${filme.id}, '${filme.titulo}')">
                                    <i class="bi bi-ticket-perforated me-1"></i> Comprar Ingresso
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            container.appendChild(col);
        });
    } catch (erro) {
        console.error('Erro na requisição dos filmes:', erro);
    }
}

// -------------------------------------------------------------
// 2. BUSCA EM TEMPO REAL
// -------------------------------------------------------------
function configurarBusca() {
    const formPesquisa = document.querySelector('.barra-pesquisa');
    if (!formPesquisa) return;

    formPesquisa.addEventListener('submit', (event) => {
        event.preventDefault();
        const termo = formPesquisa.querySelector('input').value.trim().toLowerCase();

        const cards = document.querySelectorAll('.card');
        cards.forEach((card) => {
            const texto = card.innerText.toLowerCase();
            const containerCol = card.closest('.col');
            if (containerCol) {
                containerCol.style.display = texto.includes(termo) ? 'block' : 'none';
            }
        });
    });
}

// -------------------------------------------------------------
// 3. CADASTRO DE USUÁRIO E REDIRECIONAMENTO
// -------------------------------------------------------------
function configurarFormularioCadastro() {
    const formCadastro = document.querySelector('.card-cadastro form');
    if (!formCadastro) return;

    formCadastro.addEventListener('submit', (event) => {
        event.preventDefault();

        const nome = document.getElementById('nome').value.trim();
        const senha = document.getElementById('senha').value;
        const confirmarSenha = document.getElementById('confirmarSenha').value;

        if (senha.length < 6) {
            exibirAlerta('A senha deve ter pelo menos 6 caracteres.', 'warning');
            return;
        }

        if (senha !== confirmarSenha) {
            exibirAlerta('As senhas não coincidem.', 'danger');
            return;
        }

        // Salva dados locais do usuário ativo
        localStorage.setItem('devflix_cliente', nome);
        exibirAlerta(`Bem-vindo(a), ${nome}! Redirecionando para a página inicial...`, 'success');

        // Redireciona para a página inicial após 1.5 segundos
        setTimeout(() => {
            window.location.href = 'paginainicial.html';
        }, 1500);
    });
}

// -------------------------------------------------------------
// 4. COMPRAR INGRESSO (POST /ingressos)
// -------------------------------------------------------------
async function comprarIngresso(filmeId, tituloFilme) {
    const nomeCliente = localStorage.getItem('devflix_cliente');

    // Se o usuário não fez cadastro, redireciona para a página de cadastro
    if (!nomeCliente) {
        exibirAlerta('Por favor, faça seu cadastro para comprar ingressos.', 'warning');
        setTimeout(() => {
            window.location.href = 'cadastro.html';
        }, 1500);
        return;
    }

    try {
        const resposta = await fetch(`${API_BASE_URL}/ingressos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                sessao_id: filmeId,
                nome_cliente: nomeCliente,
                quantidade: 1
            })
        });

        const dados = await resposta.json();

        if (resposta.ok) {
            exibirAlerta(`Ingresso para "${tituloFilme}" reservado com sucesso!`, 'success');
            adicionarAoCarrinhoLocal({ id: dados.id, titulo: `Ingresso: ${tituloFilme}`, preco: 25.00 });
        } else {
            exibirAlerta(dados.erro || 'Erro ao registrar ingresso.', 'danger');
        }
    } catch (erro) {
        exibirAlerta('Erro de conexão com o servidor.', 'danger');
    }
}

// -------------------------------------------------------------
// CARRINHO DE COMPRAS E ALERTAS
// -------------------------------------------------------------
function adicionarAoCarrinhoLocal(item) {
    const carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    carrinho.push(item);
    localStorage.setItem('devflix_carrinho', JSON.stringify(carrinho));
    atualizarContadorCarrinho();
}

function atualizarContadorCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    const iconeCarrinho = document.querySelector('a[href="carrinho.html"]');

    if (iconeCarrinho) {
        let badge = iconeCarrinho.querySelector('.badge');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle';
            badge.style.fontSize = '0.65rem';
            iconeCarrinho.classList.add('position-relative');
            iconeCarrinho.appendChild(badge);
        }
        badge.innerText = carrinho.length;
        badge.style.display = carrinho.length > 0 ? 'inline-block' : 'none';
    }
}

function exibirAlerta(mensagem, tipo) {
    const alertaExistente = document.querySelector('.alert-floating');
    if (alertaExistente) alertaExistente.remove();

    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 z-3 alert-floating shadow-lg`;
    alerta.innerHTML = `
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alerta);

    setTimeout(() => alerta.remove(), 3500);
}