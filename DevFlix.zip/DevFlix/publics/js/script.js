const API_BASE_URL = 'http://localhost:3000';

document.addEventListener('DOMContentLoaded', () => {
    atualizarContadorCarrinho();

    // Identifica se está na página que lista os filmes
    if (document.getElementById('container-filmes-api')) {
        carregarFilmesAPI();
    }

    configurarBusca();
    configurarFormularios();
    configurarBotoesCombo();
    carregarCarrinho();
});

// -------------------------------------------------------------
// HELPER: FORMATAÇÃO DE DATA E HORA
// -------------------------------------------------------------
function formatarHorario(stringHorario) {
    if (!stringHorario) return '';

    // Converte a string ISO/SQL em um objeto Date do JavaScript
    const data = new Date(stringHorario);

    if (!isNaN(data.getTime())) {
        const dia = String(data.getDate()).padStart(2, '0');
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const horas = String(data.getHours()).padStart(2, '0');
        const minutos = String(data.getMinutes()).padStart(2, '0');
        return `${dia}/${mes} às ${horas}:${minutos}`;
    }

    // Fallback caso seja recebid em formato de texto bruto "YYYY-MM-DD HH:mm:ss"
    const separador = stringHorario.includes('T') ? 'T' : ' ';
    const partes = stringHorario.split(separador);

    if (partes.length >= 2) {
        const [ano, mes, dia] = partes[0].split('-');
        const horaMinuto = partes[1].substring(0, 5);
        if (dia && mes && horaMinuto) {
            return `${dia}/${mes} às ${horaMinuto}`;
        }
    }

    return stringHorario;
}

// -------------------------------------------------------------
// 1. CARREGAR FILMES E SESSÕES DO BANCO DE DADOS
// -------------------------------------------------------------
async function carregarFilmesAPI() {
    const container = document.getElementById('container-filmes-api');
    if (!container) return;

    try {
        // Busca filmes e sessões em paralelo
        const [respostaFilmes, respostaSessoes] = await Promise.all([
            fetch(`${API_BASE_URL}/filmes`),
            fetch(`${API_BASE_URL}/sessoes`).catch(() => null)
        ]);

        if (!respostaFilmes.ok) throw new Error('Erro ao buscar filmes');

        const filmes = await respostaFilmes.json();
        const sessoes = (respostaSessoes && respostaSessoes.ok) ? await respostaSessoes.json() : [];

        container.innerHTML = '';

        if (filmes.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center text-secondary py-4">
                    <h5>Nenhum filme com ingressos disponíveis no momento.</h5>
                </div>
            `;
            return;
        }

        filmes.forEach(filme => {
            // Filtra as sessões referentes ao ID do filme
            const sessoesDoFilme = sessoes.filter(s => 
                Number(s.filme_id) === Number(filme.id) || 
                (s.filme && s.filme.toLowerCase() === filme.titulo.toLowerCase())
            );

            // Monta o HTML dos botões de horário
            let horariosHTML = '';
            if (sessoesDoFilme.length > 0) {
                horariosHTML = sessoesDoFilme.map(sessao => {
                    const horarioFormatado = formatarHorario(sessao.horario);
                    
                    // Extrai corretamente o ID/número da sala retornada do banco
                    const numSala = sessao.sala_id ?? sessao.sala ?? sessao.numero_sala;
                    const infoSala = (numSala !== undefined && numSala !== null) ? ` (Sala ${numSala})` : '';

                    return `
                        <button class="btn btn-outline-danger btn-sm me-1 mb-1 btn-comprar-ingresso"
                                data-filme-id="${filme.id}"
                                data-filme-titulo="${filme.titulo}"
                                data-sessao-id="${sessao.id}"
                                data-horario="${horarioFormatado}">
                            <i class="bi bi-clock me-1"></i>${horarioFormatado}${infoSala}
                        </button>
                    `;
                }).join('');
            } else {
                horariosHTML = `<small class="text-muted">Sem horários disponíveis</small>`;
            }

            const col = document.createElement('div');
            col.className = 'col card-filme-item';
            col.innerHTML = `
                <div class="card h-100 shadow-sm">
                    <div class="row g-0 h-100">
                        <div class="col-md-4">
                            <img src="${filme.poster_url || 'https://via.placeholder.com/150x225?text=Sem+Capa'}"
                                 class="img-fluid rounded-start h-100 object-fit-cover"
                                 alt="${filme.titulo}">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body d-flex flex-column h-100">
                                <h5 class="card-title fw-bold">${filme.titulo}</h5>
                                <p class="card-text mb-1"><small class="text-secondary">Gênero: ${filme.genero || 'N/A'}</small></p>
                                <p class="card-text mb-1"><small class="text-secondary">Duração: ${filme.duracao ? filme.duracao + ' min' : 'N/A'}</small></p>
                                <p class="card-text mb-2"><small class="badge bg-danger">${filme.classificacao || 'Livre'}</small></p>
                                
                                <div class="mt-auto pt-2">
                                    <p class="card-text mb-1"><small class="fw-bold text-dark">Sessões disponíveis:</small></p>
                                    <div class="d-flex flex-wrap align-items-center gap-1">
                                        ${horariosHTML}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            container.appendChild(col);
        });

        // Event listener via delegação nos botões de compra
        container.addEventListener('click', (event) => {
            const botao = event.target.closest('.btn-comprar-ingresso');
            if (!botao) return;

            const filmeId = Number(botao.dataset.filmeId);
            const filmeTitulo = botao.dataset.filmeTitulo;
            const sessaoId = Number(botao.dataset.sessaoId) || null;
            const horario = botao.dataset.horario || '';

            comprarIngresso(filmeId, filmeTitulo, sessaoId, horario);
        });
    } catch (erro) {
        console.error('Erro na requisição dos filmes e sessões:', erro);
    }
}

// -------------------------------------------------------------
// 2. BUSCA EM TEMPO REAL
// -------------------------------------------------------------
function configurarBusca() {
    const formPesquisa = document.querySelector('.barra-pesquisa');
    if (!formPesquisa) return;

    formPesquisa.addEventListener('submit', (event) => {
        event.preventDefault();
        const termo = formPesquisa.querySelector('input').value.trim().toLowerCase();

        const cards = document.querySelectorAll('.card');
        cards.forEach((card) => {
            const texto = card.innerText.toLowerCase();
            const containerCol = card.closest('.col');
            if (containerCol) {
                containerCol.style.display = texto.includes(termo) ? 'block' : 'none';
            }
        });
    });
}

// -------------------------------------------------------------
// 3. FORMULÁRIOS DE CADASTRO E LOGIN
// -------------------------------------------------------------
function configurarFormularios() {
    const formularios = document.querySelectorAll('.card-cadastro form, form');

    formularios.forEach((form) => {
        if (form.querySelector('#nome') && form.querySelector('#confirmarSenha')) {
            configurarFormularioCadastro(form);
        } else if (form.querySelector('#email') && form.querySelector('#senha') && !form.querySelector('#nome')) {
            configurarFormularioLogin(form);
        }
    });
}

function configurarFormularioCadastro(formCadastro) {
    formCadastro.addEventListener('submit', async (event) => {
        event.preventDefault();

        const nome = document.getElementById('nome').value.trim();
        const email = document.getElementById('email')?.value.trim() || '';
        const senha = document.getElementById('senha').value;
        const confirmarSenha = document.getElementById('confirmarSenha').value;

        if (senha.length < 6) {
            exibirAlerta('A senha deve ter pelo menos 6 caracteres.', 'warning');
            return;
        }

        if (senha !== confirmarSenha) {
            exibirAlerta('As senhas não coincidem.', 'danger');
            return;
        }

        try {
            const resposta = await fetch(`${API_BASE_URL}/usuarios`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, email, senha })
            });

            if (!resposta.ok) {
                const dados = await resposta.json();
                throw new Error(dados.erro || 'Erro no servidor ao cadastrar.');
            }
        } catch (erro) {
            console.warn('Backend indisponível ou erro:', erro.message);
        }

        localStorage.setItem('devflix_cliente', nome);
        exibirAlerta(`Bem-vindo(a), ${nome}! Cadastro concluído.`, 'success');

        setTimeout(() => {
            window.location.href = 'paginainicial.html';
        }, 1500);
    });
}

function configurarFormularioLogin(formLogin) {
    formLogin.addEventListener('submit', async (event) => {
        event.preventDefault();

        const email = document.getElementById('email').value.trim();
        const senha = document.getElementById('senha').value;

        if (!email || !senha) {
            exibirAlerta('Preencha e-mail e senha para entrar.', 'warning');
            return;
        }

        let nomeCliente = email.split('@')[0];

        try {
            const resposta = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, senha })
            });

            if (resposta.ok) {
                const dados = await resposta.json();
                if (dados.usuario && dados.usuario.nome) {
                    nomeCliente = dados.usuario.nome;
                }
            } else {
                const dados = await resposta.json();
                exibirAlerta(dados.erro || 'E-mail ou senha inválidos.', 'danger');
                return;
            }
        } catch (erro) {
            console.warn('Backend indisponível. Login local realizado.');
        }

        localStorage.setItem('devflix_cliente', nomeCliente);
        exibirAlerta(`Login realizado com sucesso! Bem-vindo, ${nomeCliente}.`, 'success');

        setTimeout(() => {
            window.location.href = 'paginainicial.html';
        }, 1200);
    });
}

// -------------------------------------------------------------
// 4. COMPRAR INGRESSO DA SESSÃO SELECIONADA
// -------------------------------------------------------------
async function comprarIngresso(filmeId, tituloFilme, sessaoId = null, horario = '') {
    const nomeCliente = localStorage.getItem('devflix_cliente');

    if (!nomeCliente) {
        exibirAlerta('Por favor, faça login ou cadastre-se para comprar ingressos.', 'warning');
        setTimeout(() => { window.location.href = 'cadastro.html'; }, 1200);
        return;
    }

    let sessaoIdEncontrada = sessaoId;

    if (!sessaoIdEncontrada) {
        try {
            const respostaSessoes = await fetch(`${API_BASE_URL}/sessoes`);
            if (respostaSessoes.ok) {
                const sessoes = await respostaSessoes.json();
                const sessao = sessoes.find((s) => Number(s.filme_id) === Number(filmeId) || s.filme === tituloFilme);
                if (sessao) sessaoIdEncontrada = sessao.id;
            }
        } catch (erro) {
            console.warn('API de sessões offline.');
        }
    }

    const tituloItem = horario ? `Ingresso: ${tituloFilme} (${horario})` : `Ingresso: ${tituloFilme}`;

    adicionarAoCarrinhoLocal({
        id: Date.now(),
        sessao_id: sessaoIdEncontrada,
        titulo: tituloItem,
        preco: 25.00,
        quantidade: 1
    });

    window.location.href = 'carrinho.html';
}

// -------------------------------------------------------------
// 5. BOTÕES "COMPRAR" DOS COMBOS
// -------------------------------------------------------------
function configurarBotoesCombo() {
    const iconesCombo = document.querySelectorAll('.card-body .bi-cart-plus');

    iconesCombo.forEach((icone) => {
        const botao = icone.closest('button');
        if (!botao) return;

        const card = botao.closest('.card');
        const titulo = card?.querySelector('.card-title')?.textContent.trim() || 'Combo';
        const precoTexto = card?.querySelector('.text-danger')?.textContent || '';
        const preco = parseFloat(
            precoTexto.replace('R$', '').trim().replace(/\./g, '').replace(',', '.')
        ) || 0;

        botao.addEventListener('click', () => {
            adicionarAoCarrinhoLocal({ titulo, preco, quantidade: 1 });
            exibirAlerta(`"${titulo}" adicionado ao carrinho!`, 'success');
        });
    });
}

// -------------------------------------------------------------
// 6. GERENCIAMENTO DO CARRINHO (LOCALSTORAGE)
// -------------------------------------------------------------
function adicionarAoCarrinhoLocal(item) {
    const carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    carrinho.push(item);
    localStorage.setItem('devflix_carrinho', JSON.stringify(carrinho));
    atualizarContadorCarrinho();
}

function atualizarContadorCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    const totalItens = carrinho.reduce((soma, item) => soma + (item.quantidade || 1), 0);

    const iconeCarrinho = document.querySelector('a[href="carrinho.html"]');

    if (iconeCarrinho) {
        let badge = iconeCarrinho.querySelector('.badge');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle';
            badge.style.fontSize = '0.65rem';
            iconeCarrinho.classList.add('position-relative');
            iconeCarrinho.appendChild(badge);
        }
        badge.innerText = totalItens;
        badge.style.display = totalItens > 0 ? 'inline-block' : 'none';
    }

    const contadorCarrinhoPagina = document.getElementById('contador-carrinho');
    if (contadorCarrinhoPagina) {
        contadorCarrinhoPagina.innerText = totalItens;
    }
}

function exibirAlerta(mensagem, tipo) {
    const alertaExistente = document.querySelector('.alert-floating');
    if (alertaExistente) alertaExistente.remove();

    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 z-3 alert-floating shadow-lg`;
    alerta.innerHTML = `
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alerta);

    setTimeout(() => alerta.remove(), 3500);
}

function carregarCarrinho() {
    const listaCarrinho = document.getElementById('lista-carrinho');
    const carrinhoVazio = document.getElementById('carrinho-vazio');
    const totalItens = document.getElementById('total-itens');
    const valorTotal = document.getElementById('valor-total');

    if (!listaCarrinho) return;

    let carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    listaCarrinho.innerHTML = '';

    if (carrinho.length === 0) {
        if (carrinhoVazio) carrinhoVazio.style.display = 'block';
        if (totalItens) totalItens.textContent = '0';
        if (valorTotal) valorTotal.textContent = 'R$ 0,00';
        atualizarContadorCarrinho();
        return;
    }

    if (carrinhoVazio) carrinhoVazio.style.display = 'none';

    let quantidadeTotal = 0;
    let valorTotalCompra = 0;

    carrinho.forEach((item, index) => {
        const quantidade = item.quantidade || 1;
        const preco = Number(item.preco) || 0;

        quantidadeTotal += quantidade;
        valorTotalCompra += preco * quantidade;

        const div = document.createElement('div');
        div.className = 'item-carrinho mb-3 p-3 border rounded shadow-sm';
        div.innerHTML = `
            <div class="d-flex justify-content-between align-items-start gap-3">
                <div>
                    <h5>${item.titulo}</h5>
                    <p class="mb-1 text-muted">Preço: R$ ${preco.toFixed(2).replace('.', ',')}</p>
                    <div class="quantidade-controle">
                        <button class="btn btn-sm btn-outline-secondary" onclick="alterarQuantidade(${index}, -1)">−</button>
                        <span class="quantidade mx-2">${quantidade}</span>
                        <button class="btn btn-sm btn-outline-secondary" onclick="alterarQuantidade(${index}, 1)">+</button>
                    </div>
                </div>
                <button class="btn btn-outline-danger btn-sm" onclick="removerDoCarrinho(${index})">
                    <i class="bi bi-trash"></i> Remover
                </button>
            </div>
        `;

        listaCarrinho.appendChild(div);
    });

    if (totalItens) totalItens.textContent = quantidadeTotal;
    if (valorTotal) valorTotal.textContent = `R$ ${valorTotalCompra.toFixed(2).replace('.', ',')}`;

    atualizarContadorCarrinho();
}

// -------------------------------------------------------------
// FUNÇÕES GLOBAIS PARA O CARRINHO
// -------------------------------------------------------------
window.alterarQuantidade = function(index, quantidade) {
    let carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    if (!carrinho[index]) return;

    carrinho[index].quantidade = (carrinho[index].quantidade || 1) + quantidade;

    if (carrinho[index].quantidade <= 0) {
        carrinho.splice(index, 1);
    }

    localStorage.setItem('devflix_carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
};

window.removerDoCarrinho = function(index) {
    let carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    carrinho.splice(index, 1);
    localStorage.setItem('devflix_carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
};

window.limparCarrinho = function() {
    localStorage.removeItem('devflix_carrinho');
    carregarCarrinho();
};

window.finalizarCompra = async function() {
    let carrinho = JSON.parse(localStorage.getItem('devflix_carrinho')) || [];
    const nomeCliente = localStorage.getItem('devflix_cliente');

    if (carrinho.length === 0) {
        exibirAlerta('Seu carrinho está vazio!', 'warning');
        return;
    }

    if (!nomeCliente) {
        exibirAlerta('Por favor, faça login para concluir a compra.', 'warning');
        setTimeout(() => { window.location.href = 'cadastro.html'; }, 1500);
        return;
    }

    try {
        const resposta = await fetch(`${API_BASE_URL}/finalizar-compra`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                nome_cliente: nomeCliente,
                itens: carrinho
            })
        });

        const dados = await resposta.json();

        if (resposta.ok) {
            exibirAlerta('Compra finalizada com sucesso!', 'success');
            localStorage.removeItem('devflix_carrinho');

            setTimeout(() => { 
                carregarCarrinho();
                if (typeof carregarFilmesAPI === 'function') {
                    carregarFilmesAPI();
                }
            }, 1500);
        } else {
            exibirAlerta(dados.erro || 'Erro ao processar compra.', 'danger');
        }
    } catch (erro) {
        console.error('Erro:', erro);
        exibirAlerta('Erro ao conectar com o servidor. Verifique se o backend está em execução.', 'danger');
    }
};