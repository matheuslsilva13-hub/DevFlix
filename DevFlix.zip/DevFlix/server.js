const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();

app.use(express.json());

// Servir arquivos estáticos da pasta publics/publics
app.use(express.static(path.join(__dirname, 'publics', 'publics')));

// Conexão com o banco de dados MySQL
const banco = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cinema_db'
});

banco.connect((erro) => {
    if (erro) {
        console.log('Erro ao conectar ao banco:', erro.message);
    } else {
        console.log('Banco de dados conectado com sucesso!');
    }
});

// --- ROTA RAIZ ---
// Redireciona http://localhost:3000 para a página de cadastro
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'publics', 'publics', 'cadastro.html'));
});

// --- FILMES ---

// Listar todos os filmes
app.get('/filmes', (req, res) => {
    banco.query('SELECT * FROM filmes', (erro, resultados) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.json(resultados);
    });
});

// Buscar filme por ID
app.get('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM filmes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.length === 0) {
            return res.status(404).json({ mensagem: 'Filme não encontrado' });
        }
        res.json(resultado[0]);
    });
});

// Cadastrar novo filme
app.post('/filmes', (req, res) => {
    const { titulo, genero, duracao, classificacao } = req.body;
    const sql = `
        INSERT INTO filmes (titulo, genero, duracao, classificacao)
        VALUES (?, ?, ?, ?)
    `;

    banco.query(sql, [titulo, genero, duracao, classificacao], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.status(201).json({
            mensagem: 'Filme cadastrado com sucesso!',
            id: resultado.insertId
        });
    });
});

// Alterar um filme
app.put('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const { titulo, genero, duracao, classificacao } = req.body;

    const sql = `
        UPDATE filmes
        SET titulo = ?, genero = ?, duracao = ?, classificacao = ?
        WHERE id = ?
    `;

    banco.query(sql, [titulo, genero, duracao, classificacao, id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Filme não encontrado' });
        }
        res.json({ mensagem: 'Filme alterado com sucesso!' });
    });
});

// Excluir um filme
app.delete('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM filmes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Filme não encontrado' });
        }
        res.json({ mensagem: 'Filme excluído com sucesso!' });
    });
});

// --- SALAS ---

// Listar todas as salas
app.get('/salas', (req, res) => {
    banco.query('SELECT * FROM salas', (erro, resultados) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.json(resultados);
    });
});

// Buscar sala por ID
app.get('/salas/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM salas WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.length === 0) {
            return res.status(404).json({ mensagem: 'Sala não encontrada' });
        }
        res.json(resultado[0]);
    });
});

// Cadastrar nova sala
app.post('/salas', (req, res) => {
    const { numero, capacidade } = req.body;
    const sql = `
        INSERT INTO salas (numero, capacidade)
        VALUES (?, ?)
    `;

    banco.query(sql, [numero, capacidade], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.status(201).json({
            mensagem: 'Sala cadastrada com sucesso!',
            id: resultado.insertId
        });
    });
});

// Alterar uma sala
app.put('/salas/:id', (req, res) => {
    const id = req.params.id;
    const { numero, capacidade } = req.body;

    const sql = `
        UPDATE salas
        SET numero = ?, capacidade = ?
        WHERE id = ?
    `;

    banco.query(sql, [numero, capacidade, id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Sala não encontrada' });
        }
        res.json({ mensagem: 'Sala alterada com sucesso!' });
    });
});

// Excluir uma sala
app.delete('/salas/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM salas WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Sala não encontrada' });
        }
        res.json({ mensagem: 'Sala excluída com sucesso!' });
    });
});

// --- SESSÕES ---

// Listar todas as sessões com informações do filme e da sala
app.get('/sessoes', (req, res) => {
    const sql = `
        SELECT
            sessoes.id,
            filmes.titulo AS filme,
            salas.numero AS sala,
            sessoes.horario
        FROM sessoes
        INNER JOIN filmes ON sessoes.filme_id = filmes.id
        INNER JOIN salas ON sessoes.sala_id = salas.id
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.json(resultados);
    });
});

// Buscar sessão por ID
app.get('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM sessoes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.length === 0) {
            return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        }
        res.json(resultado[0]);
    });
});

// Cadastrar nova sessão
app.post('/sessoes', (req, res) => {
    const { filme_id, sala_id, horario } = req.body;
    const sql = `
        INSERT INTO sessoes (filme_id, sala_id, horario)
        VALUES (?, ?, ?)
    `;

    banco.query(sql, [filme_id, sala_id, horario], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.status(201).json({
            mensagem: 'Sessão cadastrada com sucesso!',
            id: resultado.insertId
        });
    });
});

// Alterar uma sessão
app.put('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const { filme_id, sala_id, horario } = req.body;

    const sql = `
        UPDATE sessoes
        SET filme_id = ?, sala_id = ?, horario = ?
        WHERE id = ?
    `;

    banco.query(sql, [filme_id, sala_id, horario, id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        }
        res.json({ mensagem: 'Sessão alterada com sucesso!' });
    });
});

// Excluir uma sessão
app.delete('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM sessoes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        }
        res.json({ mensagem: 'Sessão excluída com sucesso!' });
    });
});

// --- INGRESSOS ---

// Listar todos os ingressos
app.get('/ingressos', (req, res) => {
    banco.query('SELECT * FROM ingressos', (erro, resultados) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.json(resultados);
    });
});

// Cadastrar novo ingresso
app.post('/ingressos', (req, res) => {
    const { sessao_id, nome_cliente, quantidade } = req.body;
    const sql = `
        INSERT INTO ingressos (sessao_id, nome_cliente, quantidade)
        VALUES (?, ?, ?)
    `;

    banco.query(sql, [sessao_id, nome_cliente, quantidade], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        res.status(201).json({
            mensagem: 'Ingresso cadastrado com sucesso!',
            id: resultado.insertId
        });
    });
});

// Buscar ingresso por ID
app.get('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM ingressos WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.length === 0) {
            return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        }
        res.json(resultado[0]);
    });
});

// Alterar um ingresso
app.put('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const { sessao_id, nome_cliente, quantidade } = req.body;

    const sql = `
        UPDATE ingressos
        SET sessao_id = ?, nome_cliente = ?, quantidade = ?
        WHERE id = ?
    `;

    banco.query(sql, [sessao_id, nome_cliente, quantidade, id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        }
        res.json({ mensagem: 'Ingresso alterado com sucesso!' });
    });
});

// Excluir um ingresso
app.delete('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM ingressos WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        }
        res.json({ mensagem: 'Ingresso excluído com sucesso!' });
    });
});

// Inicialização do servidor
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});