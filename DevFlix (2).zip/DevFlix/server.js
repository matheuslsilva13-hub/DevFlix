const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();

app.use(express.json());

// Servir arquivos estáticos da pasta publics/publics
app.use(express.static(path.join(__dirname, 'publics', 'publics')));

// Conexão com o banco de dados MySQL
const banco = mysql.createConnection({
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: '',
    database: 'cinema_db'
});

banco.connect((erro) => {
    if (erro) {
        console.log('Erro ao conectar ao banco:', erro.message);
    } else {
        console.log('Banco de dados conectado com sucesso!');
    }
});

// --- ROTA RAIZ ---
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'publics', 'publics', 'cadastro.html'));
});

// --- AUTENTICAÇÃO E USUÁRIOS ---

// Cadastrar novo usuário
app.post('/usuarios', (req, res) => {
    const { nome, email, senha } = req.body;

    if (!nome || !email || !senha) {
        return res.status(400).json({ erro: 'Preencha todos os campos!' });
    }

    const sql = 'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)';

    banco.query(sql, [nome, email, senha], (erro, resultado) => {
        if (erro) {
            if (erro.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ erro: 'Este e-mail já está cadastrado!' });
            }
            return res.status(500).json({ erro: erro.message });
        }
        res.status(201).json({
            mensagem: 'Usuário cadastrado com sucesso!',
            id: resultado.insertId
        });
    });
});

// Efetuar Login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).json({ erro: 'Informe e-mail e senha!' });
    }

    const sql = 'SELECT id, nome, email FROM usuarios WHERE email = ? AND senha = ?';

    banco.query(sql, [email, senha], (erro, resultados) => {
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }
        if (resultados.length === 0) {
            return res.status(401).json({ erro: 'E-mail ou senha incorretos!' });
        }

        res.json({
            mensagem: 'Login realizado com sucesso!',
            usuario: resultados[0]
        });
    });
});

// Listar todos os usuários
app.get('/usuarios', (req, res) => {
    banco.query('SELECT id, nome, email, criado_em FROM usuarios', (erro, resultados) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.json(resultados);
    });
});

// Buscar usuário por ID
app.get('/usuarios/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT id, nome, email, criado_em FROM usuarios WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.length === 0) return res.status(404).json({ mensagem: 'Usuário não encontrado' });
        res.json(resultado[0]);
    });
});

// Alterar usuário
app.put('/usuarios/:id', (req, res) => {
    const id = req.params.id;
    const { nome, email, senha } = req.body;
    const sql = 'UPDATE usuarios SET nome = ?, email = ?, senha = ? WHERE id = ?';

    banco.query(sql, [nome, email, senha, id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Usuário não encontrado' });
        res.json({ mensagem: 'Usuário alterado com sucesso!' });
    });
});

// Excluir usuário
app.delete('/usuarios/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM usuarios WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Usuário não encontrado' });
        res.json({ mensagem: 'Usuário excluído com sucesso!' });
    });
});

// --- FILMES ---

// Retorna apenas filmes que possuem ingressos disponíveis (> 0)
app.get('/filmes', (req, res) => {
    const sql = `
        SELECT DISTINCT filmes.* 
        FROM filmes
        INNER JOIN sessoes ON sessoes.filme_id = filmes.id
        WHERE sessoes.ingressos_disponiveis > 0
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.json(resultados);
    });
});

app.get('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM filmes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.length === 0) return res.status(404).json({ mensagem: 'Filme não encontrado' });
        res.json(resultado[0]);
    });
});

app.post('/filmes', (req, res) => {
    const { titulo, genero, duracao, classificacao } = req.body;
    const sql = 'INSERT INTO filmes (titulo, genero, duracao, classificacao) VALUES (?, ?, ?, ?)';

    banco.query(sql, [titulo, genero, duracao, classificacao], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.status(201).json({ mensagem: 'Filme cadastrado com sucesso!', id: resultado.insertId });
    });
});

app.put('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const { titulo, genero, duracao, classificacao } = req.body;
    const sql = 'UPDATE filmes SET titulo = ?, genero = ?, duracao = ?, classificacao = ? WHERE id = ?';

    banco.query(sql, [titulo, genero, duracao, classificacao, id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Filme não encontrado' });
        res.json({ mensagem: 'Filme alterado com sucesso!' });
    });
});

app.delete('/filmes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM filmes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Filme não encontrado' });
        res.json({ mensagem: 'Filme excluído com sucesso!' });
    });
});

// --- SALAS ---
app.get('/salas', (req, res) => {
    banco.query('SELECT * FROM salas', (erro, resultados) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.json(resultados);
    });
});

app.get('/salas/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM salas WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.length === 0) return res.status(404).json({ mensagem: 'Sala não encontrada' });
        res.json(resultado[0]);
    });
});

app.post('/salas', (req, res) => {
    const { numero, capacidade } = req.body;
    const sql = 'INSERT INTO salas (numero, capacidade) VALUES (?, ?)';

    banco.query(sql, [numero, capacidade], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.status(201).json({ mensagem: 'Sala cadastrada com sucesso!', id: resultado.insertId });
    });
});

app.put('/salas/:id', (req, res) => {
    const id = req.params.id;
    const { numero, capacidade } = req.body;
    const sql = 'UPDATE salas SET numero = ?, capacidade = ? WHERE id = ?';

    banco.query(sql, [numero, capacidade, id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Sala não encontrada' });
        res.json({ mensagem: 'Sala alterada com sucesso!' });
    });
});

app.delete('/salas/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM salas WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Sala não encontrada' });
        res.json({ mensagem: 'Sala excluída com sucesso!' });
    });
});

// --- SESSÕES ---

// Retorna as sessões com ingressos disponíveis, formatando data e horário
app.get('/sessoes', (req, res) => {
    const sql = `
        SELECT
            sessoes.id,
            sessoes.filme_id,
            filmes.titulo AS filme,
            filmes.genero,
            filmes.poster_url,
            salas.numero AS sala,
            sessoes.horario,
            DATE_FORMAT(sessoes.horario, '%d/%m/%Y') AS data_sessao,
            DATE_FORMAT(sessoes.horario, '%H:%i') AS hora_sessao,
            sessoes.ingressos_disponiveis
        FROM sessoes
        INNER JOIN filmes ON sessoes.filme_id = filmes.id
        INNER JOIN salas ON sessoes.sala_id = salas.id
        WHERE sessoes.ingressos_disponiveis > 0
        ORDER BY sessoes.horario ASC
    `;

    banco.query(sql, (erro, resultados) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.json(resultados);
    });
});

app.get('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM sessoes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.length === 0) return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        res.json(resultado[0]);
    });
});

app.post('/sessoes', (req, res) => {
    const { filme_id, sala_id, horario, ingressos_disponiveis } = req.body;
    const sql = 'INSERT INTO sessoes (filme_id, sala_id, horario, ingressos_disponiveis) VALUES (?, ?, ?, ?)';

    banco.query(sql, [filme_id, sala_id, horario, ingressos_disponiveis || 100], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.status(201).json({ mensagem: 'Sessão cadastrada com sucesso!', id: resultado.insertId });
    });
});

app.put('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const { filme_id, sala_id, horario, ingressos_disponiveis } = req.body;
    const sql = 'UPDATE sessoes SET filme_id = ?, sala_id = ?, horario = ?, ingressos_disponiveis = ? WHERE id = ?';

    banco.query(sql, [filme_id, sala_id, horario, ingressos_disponiveis, id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        res.json({ mensagem: 'Sessão alterada com sucesso!' });
    });
});

app.delete('/sessoes/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM sessoes WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Sessão não encontrada' });
        res.json({ mensagem: 'Sessão excluída com sucesso!' });
    });
});

// --- INGRESSOS ---
app.get('/ingressos', (req, res) => {
    banco.query('SELECT * FROM ingressos', (erro, resultados) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.json(resultados);
    });
});

app.post('/ingressos', (req, res) => {
    const { sessao_id, nome_cliente, quantidade } = req.body;
    const sql = 'INSERT INTO ingressos (sessao_id, nome_cliente, quantidade) VALUES (?, ?, ?)';

    banco.query(sql, [sessao_id, nome_cliente, quantidade], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        res.status(201).json({ mensagem: 'Ingresso cadastrado com sucesso!', id: resultado.insertId });
    });
});

app.get('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM ingressos WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.length === 0) return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        res.json(resultado[0]);
    });
});

app.put('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const { sessao_id, nome_cliente, quantidade } = req.body;
    const sql = 'UPDATE ingressos SET sessao_id = ?, nome_cliente = ?, quantidade = ? WHERE id = ?';

    banco.query(sql, [sessao_id, nome_cliente, quantidade, id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        res.json({ mensagem: 'Ingresso alterado com sucesso!' });
    });
});

app.delete('/ingressos/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM ingressos WHERE id = ?';

    banco.query(sql, [id], (erro, resultado) => {
        if (erro) return res.status(500).json({ erro: erro.message });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensagem: 'Ingresso não encontrado' });
        res.json({ mensagem: 'Ingresso excluído com sucesso!' });
    });
});

// --- FINALIZAR COMPRA (Grava ingressos e subtrai ingressos da sessão) ---
app.post('/finalizar-compra', async (req, res) => {
    const { nome_cliente, itens } = req.body;

    if (!nome_cliente || !itens || !Array.isArray(itens) || itens.length === 0) {
        return res.status(400).json({ erro: 'Dados inválidos ou carrinho vazio!' });
    }

    const executarQuery = (sql, parametros) => {
        return new Promise((resolve, reject) => {
            banco.query(sql, parametros, (erro, resultado) => {
                if (erro) return reject(erro);
                resolve(resultado);
            });
        });
    };

    try {
        for (const item of itens) {
            if (item.sessao_id) {
                const qtd = item.quantidade || 1;

                // 1. Cadastra na tabela 'ingressos'
                await executarQuery(
                    'INSERT INTO ingressos (sessao_id, nome_cliente, quantidade) VALUES (?, ?, ?)',
                    [item.sessao_id, nome_cliente, qtd]
                );

                // 2. Reduz o número de ingressos na tabela 'sessoes'
                await executarQuery(
                    'UPDATE sessoes SET ingressos_disponiveis = GREATEST(0, ingressos_disponiveis - ?) WHERE id = ?',
                    [qtd, item.sessao_id]
                );
            }
        }

        res.status(200).json({ mensagem: 'Compra finalizada e ingressos atualizados no banco!' });
    } catch (erro) {
        console.error('Erro ao processar compra:', erro);
        res.status(500).json({ erro: erro.message });
    }
});

// Inicialização do servidor
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});